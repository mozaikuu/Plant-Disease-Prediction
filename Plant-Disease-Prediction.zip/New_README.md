#READ req.md
#fixed code for Test_soilmoisture
#fixed code for test_plant_disease
#fixed code for init_1
#changed pymail name and fixed code redundancy
#downloaded a blynk library
#added RPICloud.py with cloud functionality
#fixed email spamming when healthy
#fixed redundant code
#define BLYNK_TEMPLATE_ID "TMPL29psD3Xok"
#define BLYNK_TEMPLATE_NAME "plant"
#tsLaqpG3IwyHX9NYSXuClCLtCa0CLeIt
