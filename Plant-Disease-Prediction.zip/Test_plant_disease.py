import cv2
import keras
import numpy as np
import tensorflow as tf
from Pymail import *
import matplotlib.pyplot as plt
from keras.preprocessing.image import img_to_array
# from picamera2 import Picamera2, Preview
import time
from test_soilsensor import *

# Define the directory path
directory_path = './valid'

# Create the dataset
validation_set = tf.keras.utils.image_dataset_from_directory(
    directory_path,
    labels="inferred",
    label_mode="categorical",
    class_names=None,
    color_mode="rgb",
    batch_size=32,
    image_size=(128, 128),
    shuffle=True,
    seed=None,
    validation_split=None,
    subset=None,
    interpolation="bilinear",
    follow_links=False,
    crop_to_aspect_ratio=False
)

# Get the class names
class_names = validation_set.class_names
print(class_names)

cnn = tf.keras.models.load_model('./trained_plant_disease_model.h5')

# Function to preprocess and make predictions on the image
def predict_disease(image):
    # Preprocess the image
    image = cv2.resize(image, (128, 128))
    input_arr = img_to_array(image)
    input_arr = np.array([input_arr])

    # Make predictions
    predictions = cnn.predict(input_arr)
    result_index = np.argmax(predictions)

    return result_index

# Email Counter Variable
count = 1


# def make_predictions():
#     global count
#     while True:
#         # Capture frame-by-frame
#         frame = picam2.capture_array()

#         # Save the captured frame
#         cv2.imwrite(f'frame_{count}.jpg', frame)

#         # Preprocess and make predictions
#         result_index = predict_disease(frame)
#         model_prediction = class_names[result_index]

#         # Display the prediction
#         print("Predicted Disease:", model_prediction)
        
#         if count % 300 == 0:
#             if "healthy" in model_prediction.lower():
#                 count = 299
#             else:        
#                 prep_and_send_email(model_prediction, soil_moisture_sensor())
#                 count = 1
#         count += 1
#         print(count)

#         # Break the loop when 'q' is pressed
#         if cv2.waitKey(1) & 0xFF == ord('q'):
#             break

# make_predictions()

# Release the camera and close windows

# picam2.stop()
# cv2.destroyAllWindows()
